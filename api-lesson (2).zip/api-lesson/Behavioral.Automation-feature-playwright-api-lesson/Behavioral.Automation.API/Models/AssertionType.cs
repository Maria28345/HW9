namespace Behavioral.Automation.API.Models;

public enum AssertionType
{
    Be,
    Become
}