﻿using System.Text;

namespace Behavioral.Automation.Abstractions
{
    /// <summary>
    /// Deprecated interface for step definitions texts 
    /// </summary>
    public interface ITestRunnerWrapper
    {
        string StepInfoText { get; }
    }
}
