﻿namespace Behavioral.Automation.Model
{
    public enum AssertionType
    {
        Immediate,
        Continuous
    }
}