namespace Behavioral.Automation.Services.Mapping.Contract
{
    public interface IControlScopeContext: IScopeContext
    {

    }
}
