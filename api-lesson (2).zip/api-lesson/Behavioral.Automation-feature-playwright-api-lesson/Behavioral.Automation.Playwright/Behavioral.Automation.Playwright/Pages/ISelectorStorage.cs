namespace Behavioral.Automation.Playwright.Pages;

public interface ISelectorStorage
{
    
}