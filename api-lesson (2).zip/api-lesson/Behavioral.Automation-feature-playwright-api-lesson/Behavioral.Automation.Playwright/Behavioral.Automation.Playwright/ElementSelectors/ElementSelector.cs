﻿namespace Behavioral.Automation.Playwright.ElementSelectors;

public class ElementSelector
{
    public string? IdSelector { get; set; }
    
    public string? Selector { get; set; }
}